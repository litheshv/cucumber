package Testng;

 public class Task1 {
    public int Addition(int a,int b){
        return a+b;
     }
     public int Subtraction(int a,int b){
         return a-b;
     }
     public int division(int a, int b){
         return a/b;
     }
     public int multiplication(int a,int b){
         return a*b;
     }

     public int percentage(int a,int b){
         return a%b;
     }


}
